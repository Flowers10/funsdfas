#include <GL/glew.h>
#include "../Context.h"
extern GLuint g_FBO;
extern GLuint g_Tex;
extern GLuint g_RBO;

extern bool setupFrameBuffers();